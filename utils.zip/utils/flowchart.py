import streamlit as st
import google.generativeai as genai

def get_gemini_model():
    """Retrieves the Gemini Pro model from session state or initializes it."""
    if "gemini_model" not in st.session_state or st.session_state.gemini_model is None:
        try:
            st.session_state.gemini_model = genai.GenerativeModel('gemini-pro')
            st.success("Gemini model initialized for utility!")
        except Exception as e:
            st.error(f"Failed to initialize Gemini model in flowchart utility: {e}")
            return None
    return st.session_state.gemini_model

def generate_flowchart_text(document_chunks: list[str], topic: str = "") -> str:
    """Generates a text-based flowchart description from the document chunks using the Gemini model."""
    model = get_gemini_model()
    if model is None:
        return "Error: Gemini model not available for flowchart generation."

    if not document_chunks:
        st.warning("No document chunks provided for flowchart generation.")
        return ""

    full_text = "\n".join(document_chunks)

    prompt = f"""You are an AI assistant specialized in creating text-based flowchart descriptions.
    Generate a clear and concise text-based flowchart description from the following content.
    Use simple text elements to describe steps, decisions, and connections.
    If a topic is provided, focus the flowchart on that topic within the text.

    Example format for a text-based flowchart:
    START
    -> Step 1: Do something
    -> Decision: Is condition true?
        -> Yes: Step 2
        -> No: Step 3
    -> Step 4: Final action
    END

    Content to analyze:
    {full_text}

    {'Focus on the topic: ' + topic if topic else ''}

    Please provide the flowchart description in a clear, readable text format.
    """

    try:
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        st.error(f"Error generating flowchart: {e}")
        return "Failed to generate flowchart. Please try again or check the console for errors."
