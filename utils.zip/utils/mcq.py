import streamlit as st
import google.generativeai as genai
import json

def get_gemini_model():
    """Retrieves the Gemini Pro model from session state or initializes it."""
    if "gemini_model" not in st.session_state or st.session_state.gemini_model is None:
        try:
            st.session_state.gemini_model = genai.GenerativeModel('gemini-pro')
            st.success("Gemini model initialized for utility!")
        except Exception as e:
            st.error(f"Failed to initialize Gemini model in MCQ utility: {e}")
            return None
    return st.session_state.gemini_model

def generate_mcqs(document_chunks: list[str], num_mcqs: int = 10) -> list:
    """Generates multiple choice questions from the document chunks using the Gemini model."""
    model = get_gemini_model()
    if model is None:
        return []

    if not document_chunks:
        st.warning("No document chunks provided for MCQ generation.")
        return []

    full_text = "\n".join(document_chunks)

    # Craft a detailed prompt to ensure structured JSON output
    prompt = f"""You are an expert at creating multiple choice questions from provided text.
    Generate {num_mcqs} multiple choice questions (MCQs) from the following text.
    Each question should have 4 options (A, B, C, D) and a single correct answer.
    The questions should cover important concepts, facts, and details from the text.
    Ensure the questions are clear and the options are plausible distractors.

    Output the questions in a JSON array format, where each object has 'question', 'options' (an array of strings), and 'answer' (the correct option letter, e.g., 'A').

    Example JSON format:
    [
      {{
        "question": "What is the capital of France?",
        "options": ["A. Berlin", "B. Madrid", "C. Paris", "D. Rome"],
        "answer": "C"
      }}
    ]

    Text to generate MCQs from:
    {full_text}

    Please generate exactly {num_mcqs} MCQs in the specified JSON format.
    """

    try:
        response = model.generate_content(prompt)
        # Attempt to parse the response as JSON
        mcqs_json = response.text.replace('```json', '').replace('```', '').strip()
        mcqs = json.loads(mcqs_json)
        if not isinstance(mcqs, list):
            st.error("AI did not return a list of MCQs in JSON format.")
            return []
        return mcqs
    except json.JSONDecodeError as e:
        st.error(f"Failed to parse MCQs from AI response (JSON Error): {e}. Response was: {response.text[:500]}...")
        return []
    except Exception as e:
        st.error(f"Error generating MCQs: {e}")
        return []
