import streamlit as st
import google.generativeai as genai
import json
import random

def get_gemini_model():
    """Retrieves the Gemini Pro model from session state or initializes it."""
    if "gemini_model" not in st.session_state or st.session_state.gemini_model is None:
        try:
            st.session_state.gemini_model = genai.GenerativeModel('gemini-pro')
            st.success("Gemini model initialized for utility!")
        except Exception as e:
            st.error(f"Failed to initialize Gemini model in quiz utility: {e}")
            return None
    return st.session_state.gemini_model

def generate_quiz_questions(document_chunks: list[str], num_questions: int = 5) -> list:
    """Generates quiz questions (MCQs) from the document chunks using the Gemini model."""
    model = get_gemini_model()
    if model is None:
        return []

    if not document_chunks:
        st.warning("No document chunks provided for quiz question generation.")
        return []

    full_text = "\n".join(document_chunks)

    prompt = f"""You are an expert at creating quiz questions from provided text.
    Generate exactly {num_questions} multiple choice questions (MCQs) from the following text.
    Each question should have 4 options (A, B, C, D) and a single correct answer.
    The questions should be challenging and cover key information from the text.

    Output the questions in a JSON array format, where each object has 'question', 'options' (an array of strings, e.g., ['A. Option1', 'B. Option2']), and 'answer' (the correct option letter, e.g., 'A').

    Text to generate quiz questions from:
    {full_text}

    Please generate exactly {num_questions} MCQs in the specified JSON format.
    """

    try:
        response = model.generate_content(prompt)
        mcqs_json = response.text.replace('```json', '').replace('```', '').strip()
        mcqs = json.loads(mcqs_json)
        if not isinstance(mcqs, list):
            st.error("AI did not return a list of quiz MCQs in JSON format.")
            return []
        return mcqs
    except json.JSONDecodeError as e:
        st.error(f"Failed to parse quiz MCQs from AI response (JSON Error): {e}. Response was: {response.text[:500]}...")
        return []
    except Exception as e:
        st.error(f"Error generating quiz questions: {e}")
        return []

def run_quiz(document_chunks: list[str]):
    """Manages the interactive quiz session."""
    if "quiz_questions" not in st.session_state or st.session_state.quiz_questions is None:
        st.session_state.quiz_questions = []
    if "current_question_idx" not in st.session_state:
        st.session_state.current_question_idx = 0
    if "quiz_score" not in st.session_state:
        st.session_state.quiz_score = 0
    if "quiz_active" not in st.session_state:
        st.session_state.quiz_active = False
    if "selected_option" not in st.session_state:
        st.session_state.selected_option = None

    num_questions = st.number_input("Number of quiz questions:", min_value=1, max_value=20, value=5, step=1)

    if st.button("Start New Quiz"):
        st.session_state.quiz_questions = generate_quiz_questions(document_chunks, num_questions)
        if st.session_state.quiz_questions:
            st.session_state.current_question_idx = 0
            st.session_state.quiz_score = 0
            st.session_state.quiz_active = True
            st.session_state.selected_option = None
            st.success(f"Quiz started with {len(st.session_state.quiz_questions)} questions!")
        else:
            st.error("Could not generate quiz questions. Please check document content and try again.")
            st.session_state.quiz_active = False

    if st.session_state.quiz_active and st.session_state.quiz_questions:
        question = st.session_state.quiz_questions[st.session_state.current_question_idx]
        st.subheader(f"Question {st.session_state.current_question_idx + 1}/{len(st.session_state.quiz_questions)}")
        st.write(f"**{question['question']}**")

        options_labels = [opt.split('. ')[0] for opt in question['options']]
        selected_option = st.radio(
            "Choose your answer:",
            options_labels,
            key=f"question_{st.session_state.current_question_idx}",
            index=None
        )

        if st.button("Submit Answer"):
            if selected_option is None:
                st.warning("Please select an option before submitting.")
            else:
                st.session_state.selected_option = selected_option
                if selected_option == question['answer']:
                    st.session_state.quiz_score += 1
                    st.success("Correct Answer!")
                else:
                    st.error(f"Wrong Answer. The correct answer was {question['answer']}.")

                # Move to next question or end quiz
                if st.session_state.current_question_idx < len(st.session_state.quiz_questions) - 1:
                    st.session_state.current_question_idx += 1
                    st.session_state.selected_option = None # Reset for next question
                    st.experimental_rerun() # Rerun to display next question
                else:
                    st.session_state.quiz_active = False
                    st.info("Quiz finished!")
                    st.balloons()
                    st.subheader(f"Your final score: {st.session_state.quiz_score}/{len(st.session_state.quiz_questions)}")
                    st.session_state.quiz_questions = [] # Clear questions after quiz

    elif st.session_state.quiz_active and not st.session_state.quiz_questions:
        st.warning("No quiz questions available. Please generate some first.")

    if not st.session_state.quiz_active and st.session_state.quiz_questions and st.session_state.current_question_idx >= len(st.session_state.quiz_questions):
        st.subheader(f"Your final score: {st.session_state.quiz_score}/{len(st.session_state.quiz_questions)}")
