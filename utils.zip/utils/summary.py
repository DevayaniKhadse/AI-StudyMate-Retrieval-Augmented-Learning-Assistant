import streamlit as st
import google.generativeai as genai

def get_gemini_model():
    """Retrieves the Gemini Pro model from session state or initializes it."""
    if "gemini_model" not in st.session_state or st.session_state.gemini_model is None:
        try:
            st.session_state.gemini_model = genai.GenerativeModel('gemini-pro')
            st.success("Gemini model initialized for utility!")
        except Exception as e:
            st.error(f"Failed to initialize Gemini model in summary utility: {e}")
            return None
    return st.session_state.gemini_model

def generate_summary(document_chunks: list[str], summary_type: str) -> str:
    """Generates a summary of the document chunks using the Gemini model."""
    model = get_gemini_model()
    if model is None:
        return "Error: Gemini model not available for summarization."

    if not document_chunks:
        return "No document chunks provided for summarization."

    full_text = "\n".join(document_chunks)

    prompt_templates = {
        "Quick Summary": "Provide a concise summary of the following text:\n\n{text}",
        "Exam-focused Summary": "Generate an exam-focused summary, highlighting key concepts, definitions, and potential exam questions from the following text:\n\n{text}",
        "Key Concepts": "Extract and list the most important key concepts and their brief explanations from the following text:\n\n{text}"
    }

    prompt = prompt_templates.get(summary_type, prompt_templates["Quick Summary"])
    prompt = prompt.format(text=full_text)

    try:
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        st.error(f"Error generating summary: {e}")
        return "Failed to generate summary. Please try again or check the console for errors."
