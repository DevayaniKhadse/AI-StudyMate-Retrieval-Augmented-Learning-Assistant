import streamlit as st
import google.generativeai as genai

def get_gemini_model():
    """Retrieves the Gemini Pro model from session state or initializes it."""
    if "gemini_model" not in st.session_state or st.session_state.gemini_model is None:
        try:
            st.session_state.gemini_model = genai.GenerativeModel('gemini-pro')
            st.success("Gemini model initialized for utility!")
        except Exception as e:
            st.error(f"Failed to initialize Gemini model in mindmap utility: {e}")
            return None
    return st.session_state.gemini_model

def generate_mindmap_text(document_chunks: list[str], topic: str = "") -> str:
    """Generates a text-based mind map description from the document chunks using the Gemini model."""
    model = get_gemini_model()
    if model is None:
        return "Error: Gemini model not available for mind map generation."

    if not document_chunks:
        st.warning("No document chunks provided for mind map generation.")
        return ""

    full_text = "\n".join(document_chunks)

    prompt = f"""You are an AI assistant specialized in creating text-based mind maps.
    Generate a clear and concise text-based mind map description from the following content.
    Use indentation and bullet points to represent the hierarchy of ideas.
    Start with a central topic, and branch out with main ideas and sub-ideas.
    If a specific topic is provided, make that the central topic of the mind map.

    Example format for a text-based mind map:
    Central Topic: Introduction to AI
    - Main Idea 1: Definition of AI
        - Sub-idea 1.1: What is AI?
        - Sub-idea 1.2: Goals of AI
    - Main Idea 2: Types of AI
        - Sub-idea 2.1: Narrow AI
        - Sub-idea 2.2: General AI

    Content to analyze:
    {full_text}

    {'Central Topic: ' + topic if topic else 'Central Topic: Main Ideas from Text'}

    Please provide the mind map description in a clear, readable text format, using indentation for hierarchy.
    """

    try:
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        st.error(f"Error generating mind map: {e}")
        return "Failed to generate mind map. Please try again or check the console for errors."
