import streamlit as st
import google.generativeai as genai

def get_gemini_model():
    """Retrieves the Gemini Pro model from session state or initializes it."""
    if "gemini_model" not in st.session_state or st.session_state.gemini_model is None:
        try:
            st.session_state.gemini_model = genai.GenerativeModel('gemini-pro')
            st.success("Gemini model initialized for utility!")
        except Exception as e:
            st.error(f"Failed to initialize Gemini model in viva utility: {e}")
            return None
    return st.session_state.gemini_model

def generate_viva_questions(document_chunks: list[str], num_questions: int = 10) -> list:
    """Generates viva/interview-style questions from the document chunks using the Gemini model."""
    model = get_gemini_model()
    if model is None:
        return []

    if not document_chunks:
        st.warning("No document chunks provided for Viva question generation.")
        return []

    full_text = "\n".join(document_chunks)

    prompt = f"""You are an expert at creating insightful viva/oral examination questions from provided text.
    Generate exactly {num_questions} open-ended, thought-provoking questions that test deep understanding and application of concepts from the following text.
    Focus on 'why', 'how', 'explain', 'compare', 'contrast', 'analyze', 'critique' type questions.

    Text to generate Viva questions from:
    {full_text}

    Please list the questions directly, one per line, without any numbering or special formatting.
    """

    try:
        response = model.generate_content(prompt)
        questions_text = response.text.strip()
        # Split by new line, filter out empty strings
        questions = [q.strip() for q in questions_text.split('\n') if q.strip()]
        
        # Post-process to ensure we get roughly the number of questions asked
        if len(questions) > num_questions:
            questions = questions[:num_questions]
        elif len(questions) < num_questions and len(document_chunks) > 1:
            st.warning(f"Could only generate {len(questions)} Viva questions out of {num_questions} requested.")

        return questions
    except Exception as e:
        st.error(f"Error generating Viva questions: {e}")
        return []
