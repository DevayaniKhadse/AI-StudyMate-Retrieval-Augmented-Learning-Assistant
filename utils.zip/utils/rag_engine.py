import streamlit as st
import google.generativeai as genai
import numpy as np

def get_rag_response(
    user_query: str,
    vector_store: dict,
    conversation: genai.GenerativeModel.start_chat,
    notes_only: bool = False,
    smart_mode: bool = True,
    similarity_threshold: float = 0.7
) -> str:
    """
    Generates a response using RAG or general AI, based on selected modes.
    """
    # Ensure Gemini model is initialized in session state
    if "gemini_model" not in st.session_state or st.session_state.gemini_model is None:
        return "Error: Gemini model not initialized. Please check API key and restart." 

    model = st.session_state.gemini_model
    retrieved_context = []
    response_text = ""

    # Check if a vector store exists and has chunks
    if vector_store and vector_store.get("index") is not None and vector_store.get("chunks"):
        faiss_index = vector_store["index"]
        text_chunks = vector_store["chunks"]
        embedding_model = vector_store["embedding_model"]

        if embedding_model is None:
            st.warning("Embedding model not available for similarity search.")
            if notes_only:
                return "No notes can be used as embedding model is unavailable." 
            # Fallback to general AI if embedding model is missing and not notes_only
            try:
                response = conversation.send_message(user_query)
                return response.text
            except Exception as e:
                return f"Error with general AI fallback: {e}"

        try:
            query_embedding = embedding_model.encode([user_query])
            # Ensure query embedding is float32 for FAISS
            query_embedding = np.array(query_embedding).astype('float32')

            # Search FAISS index for similar documents
            # k=3 retrieves the top 3 most similar chunks
            distances, indices = faiss_index.search(query_embedding, k=3)

            # Filter based on similarity threshold for Smart Mode
            for i, idx in enumerate(indices[0]):
                # FAISS returns L2 distance. Smaller distance = more similar.
                # Need to convert L2 distance to a similarity score if needed,
                # or use a distance threshold directly. For simplicity, we'll use a direct distance threshold.
                # A common practice is to treat a smaller L2 distance as higher similarity.
                # Let's consider a threshold on distance (e.g., max_distance_for_relevance)
                # This example uses similarity_threshold, so we'll need to interpret L2 distance.
                # For now, a simpler interpretation: lower distance implies higher relevance.
                # A more robust way would be to normalize or convert to cosine similarity.
                
                # For demo, let's assume `similarity_threshold` is actually a 'max_distance_threshold'
                # For L2 distance, smaller is better. So if distance is less than threshold, it's relevant.
                # We will adjust `smart_mode` logic to use actual similarity later if needed.
                # For now, let's use a simple distance cut-off based on the `similarity_threshold` value.
                
                # Let's re-interpret similarity_threshold as a relevance score for demonstration
                # A low L2 distance is good. Let's say a distance < X is relevant.
                # For now, let's just take the top-k for `notes_only` and filter for `smart_mode`.

                # To genuinely use `similarity_threshold` (0 to 1, 1 being most similar), 
                # we'd need cosine similarity. FAISS IndexFlatL2 gives L2 distance.
                # Cosine Similarity = 1 - (L2_distance^2 / 2) for normalized vectors.
                # Sentence-transformers produce normalized embeddings by default, so this conversion holds.
                
                # Convert L2 distance to cosine similarity for thresholding (assuming normalized embeddings)
                cosine_similarity = 1 - (distances[0][i]**2) / 2

                if notes_only or (smart_mode and cosine_similarity >= similarity_threshold):
                    retrieved_context.append(text_chunks[idx])

        except Exception as e:
            st.warning(f"Error during similarity search: {e}")

    # Decision Logic
    if notes_only and not retrieved_context:
        return "I couldn't find relevant information in your notes for that query. Please try rephrasing or check your uploaded documents."
    
    if retrieved_context:
        # RAG enabled path
        context_str = "\n".join(retrieved_context)
        prompt = f"Based on the following context, answer the question. If the answer is not in the context, say 'I can only answer questions based on the provided documents for notes-only mode, or if the context is insufficient, I will use my general knowledge.'.\n\nContext:\n{context_str}\n\nQuestion: {user_query}"
        try:
            response = conversation.send_message(prompt)
            response_text = response.text
        except Exception as e:
            response_text = f"Error generating response with RAG: {e}. Falling back to general AI (if applicable)."
            if notes_only: # If RAG failed in notes_only mode, don't fall back to general AI
                return "I encountered an error trying to use your notes to answer. Please try again."
    else:
        # General AI path (no context, or smart_mode decided context wasn't relevant enough)
        try:
            response = conversation.send_message(user_query)
            response_text = response.text
        except Exception as e:
            response_text = f"Error generating general AI response: {e}. Please try again later."
    
    return response_text
