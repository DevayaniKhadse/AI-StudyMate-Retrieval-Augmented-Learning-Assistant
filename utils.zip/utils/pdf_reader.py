import streamlit as st
from PyPDF2 import PdfReader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np

@st.cache_resource
def get_embedding_model():
    """Initializes and caches the SentenceTransformer model."""
    try:
        model_name = "all-MiniLM-L6-v2"
        model = SentenceTransformer(model_name)
        st.success(f"Embedding model '{model_name}' loaded successfully!")
        return model
    except Exception as e:
        st.error(f"Failed to load embedding model: {e}")
        return None

def get_pdf_text(pdf_docs):
    """Extracts text from a list of PDF documents."""
    text = ""
    try:
        pdf_reader = PdfReader(pdf_docs)
        for page in pdf_reader.pages:
            text += page.extract_text() or ""
    except Exception as e:
        st.error(f"Error reading PDF: {e}")
        return ""
    return text

def get_text_chunks(text):
    """Splits text into chunks."""
    if not text:
        return []
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200,
        length_function=len
    )
    chunks = text_splitter.split_text(text)
    return chunks

def get_vector_store(text_chunks):
    """Generates embeddings and creates a FAISS vector store from text chunks."""
    if not text_chunks:
        st.warning("No text chunks available to create vector store.")
        return None

    embedding_model = get_embedding_model()
    if embedding_model is None:
        st.error("Embedding model not available. Cannot create vector store.")
        return None

    try:
        # Generate embeddings
        # The SentenceTransformer model expects a list of strings
        embeddings = embedding_model.encode(text_chunks, show_progress_bar=True)
        
        if len(embeddings) == 0:
            st.warning("No embeddings generated from the text chunks.")
            return None

        # Convert to a format suitable for FAISS
        # Ensure embeddings are float32 as required by FAISS
        embeddings = np.array(embeddings).astype('float32')

        # Create FAISS index
        dimension = embeddings.shape[1]
        index = faiss.IndexFlatL2(dimension) # L2 distance for similarity search
        index.add(embeddings)

        # Store chunks and index together, as FAISS only stores vectors
        # We need to map back the FAISS results to the original text chunks
        vector_store = {
            "index": index,
            "chunks": text_chunks,
            "embedding_model": embedding_model
        }
        st.success(f"FAISS index created with {len(text_chunks)} chunks.")
        return vector_store

    except Exception as e:
        st.error(f"Error creating FAISS vector store: {e}")
        return None
